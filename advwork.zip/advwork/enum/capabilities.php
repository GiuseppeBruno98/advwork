<?php
/**
 * Created by PhpStorm.
 * User: Gabriel
 * Date: 6/2/2018
 * Time: 11:31 AM
 */

// Capabilities defined into the system
abstract class Capabilities extends BasicEnum {
    const K = "K";
    const J = "J";
    const C = "C";
}