<?php
/**
 * Created by PhpStorm.
 * User: Gabriel
 * Date: 5/1/2018
 * Time: 4:15 PM
 */

/**
 * Distributions of the grade over the values from the interval [A-F]
 */
class grade_distributions {
    public $distributions = array();
}